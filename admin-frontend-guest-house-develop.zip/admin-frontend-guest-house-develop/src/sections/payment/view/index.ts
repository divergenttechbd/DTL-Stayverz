export { default as PaymentView } from './payment-view';
