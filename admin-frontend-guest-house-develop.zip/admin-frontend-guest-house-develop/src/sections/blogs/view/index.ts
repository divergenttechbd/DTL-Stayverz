export { default as TourListView } from './blog-list-view';
export { default as TourDetailsView } from './blog-details-view';
