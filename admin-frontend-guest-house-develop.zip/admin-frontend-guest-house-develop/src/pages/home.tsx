import { Helmet } from 'react-helmet-async';

export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>Guest House</title>
      </Helmet>
      Hello World
    </>
  );
}
