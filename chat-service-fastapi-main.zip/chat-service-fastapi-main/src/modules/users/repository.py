from src.core.repository.base_repository import BaseRepository


class UserRepository(BaseRepository):
    pass
