from .logging_config import logger

__all__ = ["logger"]
