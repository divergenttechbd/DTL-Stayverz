from .producer import rabbitmq

__all__ = ["rabbitmq"]
