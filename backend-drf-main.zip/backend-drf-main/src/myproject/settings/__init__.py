from myproject.settings.base import *  # noqa
from myproject.settings.apps import *  # noqa
from myproject.settings.app_vars import *  # noqa
from myproject.settings.celery import *  # noqa
from myproject.settings.database import *  # noqa

# from myproject.settings.logger import *  # noqa
from myproject.settings.third_party import *  # noqa
